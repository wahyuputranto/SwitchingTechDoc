# Registrasi

---
Layanan OkeBayar hanya tersedia untuk member yang sudah terdaftar.

Daftarkan diri Anda melalui Form Registrasi dan penuhi kelengkapan data agar https://report.okebayar.com/register dapat secara optimal mendukung sistem dan bisnis Anda.

Setelah pendaftaran terverifikasi, Anda akan mendapatkan ID Member dan PIN untuk mengakses environment development OkeBayar sebagai area ujicoba integrasi sistem.

Bila Anda belum menerima konfirmasi pendaftaran dalam 1x24 jam, silakan menghubungi kontak SiapBayar (email/TG/WA) yang tertera pada situs OkeBayar.